<?php
// $pageTitle = "Add Expense";

include("./includes/header.php"); 
include("./includes/db_conn.php"); 
include("./includes/functions.php"); 
include("./includes/gen_navbar.php"); 



// For your my_alert function

if (isset($_POST['add_expense'])) {

    // 1. Get input values from the HTML form 'name' attributes
    $amount = $_POST['amount'] ?? '';
    $category_id = $_POST['expense_name'] ?? ''; // This matches the form field name
    $payment_mode = $_POST['payment_mode'] ?? '';
    $date = $_POST['date'] ?? '';
    $description = $_POST['description'] ?? ''; // optional field if added later
    $expense_name = $_POST['expense_name'] ?? '';

    // For now, we'll use a placeholder User_ID.
    // Usually, this comes from $_SESSION['user_id'] after login.
    // $user_id = 1;

    // Fetch the logged-in user's ID from the session
    $user_id = $_SESSION['reg_id'];

    // 2. The SQL Insert Query
    // Make sure these column names match exactly what you typed in phpMyAdmin
    $sql = "INSERT INTO expense (User_ID, expense_name, Amount, Payment_Mode, Date, Description)
            VALUES ('$user_id', '$expense_name', '$amount', '$payment_mode', '$date', '$description')";

    // 3. Execute and check
    if (mysqli_query($conn, $sql)) {
        my_alert("success", "Expense added successfully!");
    } else {
        // This will help you debug if something goes wrong
        my_alert("danger", "Error: " . mysqli_error($conn));
    }

    mysqli_close($conn);
}
?>  
    <link rel="stylesheet" type="text/css" href="css/addexpense.css" />
<body>
    <br>
    <div class="container">
        <h1> ADD Expense </h1>
        <form id="expense-form" action="add_expense.php" method="POST">

            <input type="text" name="expense_name" id="expense-name" placeholder="Expense Name" required />
            <input type="number" name="amount" id="expense-amount" placeholder="Amount" required />
           <input type="text" name="description" id="description-name" placeholder="Description" required />
        
            
            <input type="date" name="date" id="expense-date" required >
            
            <select name="payment_mode" id="expense-payment-mode" required>
                <option value="" disabled selected>Select Payment Mode</option>
                <option value="Cash">Cash</option>
                <option value="UPI">UPI</option>
                <option value="cards">Debit/Credit Card</option>
            </select>

            <button type="submit" name="add_expense">Add Expense</button>
             
            <a href="./manage_expense.php" class="btn-view">View Expense Records</a>
        </form>
      
    </div>
</body>
</html>



