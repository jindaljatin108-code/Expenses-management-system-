<?php
include("./includes/header.php");
include("./includes/functions.php");
include("./includes/gen_navbar.php");

$alert_html = '';
if (isset($_POST['add_income'])) {
    include("./includes/db_conn.php");

    // $user_id = 1;
    $user_id = $_SESSION['reg_id'];
    $amount = $_POST['amount'];
    $source = $_POST['source'];
    $date = $_POST['date'];

    if ($amount <= 0) {
        $alert_html = my_alert("danger", "Amount must be greater than 0", true);
    } else {
        $sql = "INSERT INTO income (user_ID, Amount, source, Date)
                VALUES ('$user_id', '$amount', '$source', '$date')";

        if (mysqli_query($conn, $sql)) {
            $alert_html = my_alert("success", "Income added successfully", true);
        } else {
            $alert_html = my_alert("danger", "Error: " . mysqli_error($conn), true);
        }
    }
    mysqli_close($conn);
}
?>

<link rel="stylesheet" href="./css/income.css">

<div class="container">
    <?php 
    if(!empty($alert_html)) {
        echo $alert_html; 
    }
    ?>
    
    <h2>ADD INCOME</h2>
    
    <form action="" method="post">
        <!-- <input type="hidden" name="user_id" value="1"> -->

        <input type="text" name="source" placeholder="Income Source" required>
        <input type="number" name="amount" placeholder="Amount" min="1" required>

        <input type="date" name="date" required>
        
        <button type="submit" name="add_income">Add Income</button>

        <a href="./display_income.php" class="btn-view">View Income Records</a>
    </form>
</div>


