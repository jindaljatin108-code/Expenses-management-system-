<?php
$title = "Display Income";
include("./includes/header.php");
include("./includes/functions.php");
include("./includes/db_conn.php");
include("./includes/gen_navbar.php");
?>

<link rel="stylesheet" href="./css/display_income.css">

<div class="container">
  
  <div class="page-header">
    <h1>Income Records</h1>
    <a href="./income.php" class="btn-add">Add New Income</a>
  </div>

  <div class="table-wrapper">
    <table class="data-table">
      <thead>
        <tr>
          <th>ID</th>
          <th>Source</th>
          <th>Amount</th>
          <th>Date</th>
          <th>Operations</th>
        </tr>
      </thead>
      <tbody>
        <?php
          $current_user_id = $_SESSION['reg_id']; // Logged-in user ki ID nikal li

          // Query mein user_ID ka filter laga diya aur Date ke hisaab se sort kar diya
          $fetch_data = "SELECT Income_ID, Amount, source, Date FROM income WHERE user_ID = '$current_user_id' ORDER BY Date DESC";
          $run_fetch_data = mysqli_query($conn, $fetch_data);
          $counter = 1;

        if(mysqli_num_rows($run_fetch_data) > 0){
          while($row = mysqli_fetch_assoc($run_fetch_data)) {
          ?>
           <tr>
            <td><strong><?php echo $counter; ?></strong></td>
            <td><?php echo htmlspecialchars($row['source']); ?></td>
            <td class="amount-cell">₹<?php echo number_format($row['Amount'], 2); ?></td>
            <td><?php echo date("d M, Y", strtotime($row['Date'])); ?></td>
            <td class="action-cells">
              <a class="btn-edit" href="./update_income.php?id=<?php echo $row['Income_ID']; ?>">Edit</a>
              <a class="btn-delete" href="./delete_income.php?id=<?php echo $row['Income_ID']; ?>">Delete</a>
            </td>
          </tr>
          <?php
          $counter++;
          }
        } else {
          ?>
          <tr>
            <td colspan="5" class="empty-state">
              No Income Records Found
            </td>
          </tr>
          <?php
        }
        mysqli_close($conn);
        ?>
      </tbody>
    </table>
  </div>
</div>
<?php
include("./includes/footer.php");
?>