<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/index.css" />
    <title>Expense Management System</title>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <span class="logo-icon">💰</span>
                Expense Management System
            </div>
            <button class="menu-toggle" id="menuToggle">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <!-- <ul class="nav-menu" id="navMenu">
                <li><a href="about.php">About</a></li>
                <li><a href="report.php">Report</a></li>
            </ul> -->
            <a href="login_user.php" class="nav-cta">Start Free</a>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-bg">
            <div class="orb orb-1"></div>
            <div class="orb orb-2"></div>
            <div class="orb orb-3"></div>
        </div>
        <div class="hero-content">
            <div class="hero-badge">
                <span class="badge-dot"></span>
                Smart Expense Tracking
            </div>
            <h1 class="hero-title">Take Control of Your <span class="highlight">Money</span></h1>
            <p class="hero-subtitle">Track every rupee, analyze spending patterns, and achieve your financial goals with ease.</p>
            <div class="hero-buttons">
                <a class="btn btn-primary" id="demoBtn" href="login_user.php">Get Started Free</a>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features" id="features">
        <div class="section-header">
            <h2>Why Choose Expense Management?</h2>
            <p>Powerful tools to help you manage finances smarter</p>
        </div>
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">📊</div>
                <h3>Smart Analytics</h3>
                <p>Real-time insights into your spending habits with interactive charts and detailed reports.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🎯</div>
                <h3>Budget Planning</h3>
                <p>Set budgets for different categories and get alerts when you're about to exceed limits.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">💳</div>
                <h3>Multi-Account</h3>
                <p>Manage multiple bank accounts, credit cards, and wallets in one unified dashboard.</p>
            </div>
        </div>
    </section>

    
    <footer class="footer">
        <div class="footer-content">
            <div class="footer-section">
                <h4>Expense Management System</h4>
                <p>Smart expense management for everyone.</p>
            </div>
            <div class="footer-section">
                
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="#">Features</a></li>
                    <li><a href="about.php">About</a></li>
                </ul>
            </div>
           
            <div class="footer-section">
                <ul>
                    <li><a href="#">Privacy Policy</a></li>
                    <p>This system does not share user data with third parties. All data is stored securely.</p>
                    <li><a href="#">Terms & Conditions </a></li>
                    <p>This project is developed for educational purposes. Users must use it responsibly.</p>
                    
                </ul>
            </div>
            
            <div class="footer-section">
                <ul>
                    <li><a href="#contact">Contact</a></li>
                    <p> Email :support@expensetrack.com</p>
                    <p> Phone :+91 12345 67892</p>
                    
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 Expense Management System. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>