<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Bootstrap Icons  -->
   <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"> -->
  <!-- Bootstrap css  -->
  <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous"> -->
  <!-- <link rel="stylesheet" href="./css/style.css"> -->
  <title>
    <?php 
       $filename =  basename($_SERVER['PHP_SELF'], ".php"); 
       $page_title =  ucfirst(str_replace("_"," ", $filename));

       if($page_title === "Index"){
        echo "Dashboard";
       }else{
        echo $page_title;
       }
    ?>
  </title>
</head>

<body>