<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

<style>
    .dashboard-header {
        background: #16213e;
        padding: 15px 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
    }

    .header-left {
        display: flex;
        align-items: center;
        gap: 20px;
    }

    .header-title h1 {
        font-size: 1.4rem;
        margin: 0;
        color: #fff;
    }

    .header-title p {
        font-size: 0.85rem;
        margin: 0;
        color: rgba(255, 255, 255, 0.6);
    }

    .popup-menu {
        position: relative;
    }

    .popup-btn {
        background: rgba(255, 255, 255, 0.1);
        border: none;
        color: white;
        padding: 10px 18px;
        border-radius: 8px;
        cursor: pointer;
        font-size: 1.1rem;
        display: flex;
        align-items: center;
        gap: 10px;
        transition: 0.3s ease;
    }

    .popup-btn:hover {
        background: rgba(255, 255, 255, 0.2);
    }

    .popup-content {
        display: none;
        position: absolute;
        top: 50px;
        left: 0;
        background: linear-gradient(135deg, #0f3460 0%, #16213e 100%);
        min-width: 220px;
        border-radius: 10px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
        z-index: 1000;
        overflow: hidden;
    }

    .popup-content.show {
        display: block;
    }

    .popup-content a {
        display: flex;
        align-items: center;
        gap: 12px;
        color: #fff;
        padding: 12px 20px;
        text-decoration: none;
        transition: 0.3s;
    }

    .popup-content a:hover {
        background: rgba(255, 255, 255, 0.1);
    }

    .popup-content a.active {
        color: #ffd700;
        background: rgba(255, 215, 0, 0.1);
    }

    .user-info {
        display: flex;
        gap: 10px;
    }

    .Profile-btn, .logout-btn {
        padding: 8px 15px;
        border-radius: 6px;
        text-decoration: none;
        font-weight: 500;
        font-size: 0.9rem;
    }

    .Profile-btn { background: #27ae60; color: white; }
    .logout-btn { background: #e94560; color: white; }
</style>

<header class="dashboard-header">
    <div class="header-left" style="display: flex; align-items: center; gap: 20px;">
        <div class="popup-menu">
            <button class="popup-btn" onclick="togglePopup()">
                <i class="fa fa-bars"></i>
                <span>Menu</span>
            </button>
            <div class="popup-content" id="popupContent">
                <a href="./dashboard.php" class="active"><i class="fa fa-dashboard"></i> Dashboard</a>
                <a href="./add_expense.php"><i class="fa fa-plus-circle"></i> Add Expense</a>
                <a href="./income.php"><i class="fa fa-money-bill"></i> Add Income</a>
                <a href="./report.php"><i class="fa fa-file-alt"></i> Reports</a>
                <a href="./logout.php"><i class="fa fa-sign-out"></i> Logout</a>
            </div>
        </div>
        <div class="header-title">
            <h1>Expense Management System</h1>
            <p>Your Personal Finance Tracker</p>
        </div>
    </div>
    <div class="user-info">
        <a href="profile.php" class="Profile-btn"><i class="fa fa-user"></i> Profile</a>
    </div>
</header>

<script>
    function togglePopup() {
        var popup = document.getElementById('popupContent');
        popup.classList.toggle('show');
    }

    document.addEventListener('click', function(event) {
        var popup = document.getElementById('popupContent');
        var popupMenu = document.querySelector('.popup-menu');
        if (!popupMenu.contains(event.target)) {
            popup.classList.remove('show');
        }
    });
</script>
