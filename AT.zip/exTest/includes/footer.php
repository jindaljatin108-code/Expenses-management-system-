<link rel="stylesheet" href="./css/footer.css">

<footer>
      <div class="geo-accent"></div>

      <div class="footer-ticker">
        <div class="ticker-inner">
          <span class="ticker-item"><span class="ticker-dot"></span> Smart Expense Management</span>
          <span class="ticker-item"><span class="ticker-dot"></span> Real-Time Budget Alerts</span>
          <span class="ticker-item"><span class="ticker-dot"></span> Secure Financial Tracking</span>
          <span class="ticker-item"><span class="ticker-dot"></span> Custom BCA Project 2026</span>
          <span class="ticker-item"><span class="ticker-dot"></span> Smart Expense Management</span>
          <span class="ticker-item"><span class="ticker-dot"></span> Real-Time Budget Alerts</span>
        </div>
      </div>

      <div class="footer-body">
        <div class="brand-col">
          <div class="brand-logo">
            <div class="logo-icon">
              <svg viewBox="0 0 24 24" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="2" y="5" width="20" height="14" rx="2" />
                <line x1="2" y1="10" x2="22" y2="10" />
                <line x1="6" y1="15" x2="10" y2="15" />
              </svg>
            </div>
            <span class="brand-name">EMS</span>
          </div>
          <p class="brand-tagline">
            Financial management built for modern tracking. Analyze and optimize every rupee spent with precision.
          </p>
        </div>

        <div class="nav-col">
          <div class="col-heading">Platform</div>
          <ul class="nav-list">
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="report.php">Expense Reports</a></li>
            <li><a href="addexpense.php">Add Expense</a></li>
          </ul>
        </div>

        <div class="nav-col">
          <div class="col-heading">Account</div>
          <ul class="nav-list">
            <li><a href="update_profile.php">Profile Settings</a></li>
            <li><a href="logout.php">Logout</a></li>
          </ul>
        </div>
      </div>

      <div class="footer-bottom">
        <p class="copyright">
          © <?php echo date("Y"); ?> <strong>SpendWise</strong>. All rights reserved. Made by Jatin Jindal.
        </p>
        <div class="footer-links">
          <a href="#">Privacy Policy</a>
          <a href="#">Terms of Service</a>
        </div>
        <div class="social-row">
          <a href="#" class="social-btn" title="GitHub">
            <i class="fab fa-github"></i>
          </a>
        </div>
      </div>
</footer>

<div id="deleteModalOverlay" class="delete-modal-overlay">
  <div class="delete-modal-box">
    <div class="modal-warning-icon">🗑️</div>
    <h3>Delete Record?</h3>
    <p>Are you sure you want to delete this? This action cannot be undone.</p>
    <div class="modal-buttons">
      <button id="cancelDeleteBtn" class="modal-btn-cancel">Cancel</button>
      <a href="#" id="confirmDeleteBtn" class="modal-btn-confirm">Yes, Delete</a>
    </div>
  </div>
</div>

<style>
/* --- Modal CSS --- */
.delete-modal-overlay {
  display: none; /* Hidden by default */
  position: fixed;
  top: 0; left: 0; width: 100%; height: 100%;
  background: rgba(37, 61, 44, 0.7); /* Deep green transparent overlay */
  z-index: 9999;
  align-items: center;
  justify-content: center;
  backdrop-filter: blur(4px); /* Beautiful frosted glass effect */
}

.delete-modal-box {
  background: #ffffff;
  padding: 35px 40px;
  border-radius: 15px;
  text-align: center;
  max-width: 400px;
  width: 90%;
  box-shadow: 0 15px 40px rgba(0,0,0,0.25);
  animation: popIn 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275); /* Smooth bouncy entrance */
}

@keyframes popIn {
  0% { transform: scale(0.8); opacity: 0; }
  100% { transform: scale(1); opacity: 1; }
}

.modal-warning-icon {
  font-size: 45px;
  margin-bottom: 10px;
}

.delete-modal-box h3 {
  color: #2E6F40; /* Dark Green */
  margin: 0 0 10px;
  font-weight: 700;
  letter-spacing: 0.5px;
  font-family: 'Poppins', sans-serif;
}

.delete-modal-box p {
  color: #4a5d50;
  margin-bottom: 25px;
  font-size: 0.95rem;
  font-family: 'Poppins', sans-serif;
}

.modal-buttons {
  display: flex;
  gap: 15px;
  justify-content: center;
}

.modal-btn-cancel {
  background: transparent;
  color: #4a5d50;
  border: 2px solid #e0e5e2;
  padding: 12px 24px;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  font-family: 'Poppins', sans-serif;
}

.modal-btn-cancel:hover {
  background: #f4faf6;
  border-color: #68BA7F;
  color: #2E6F40;
}

.modal-btn-confirm {
  background: #ff416c; /* Warning Red */
  color: white !important;
  border: none;
  padding: 12px 24px;
  border-radius: 8px;
  font-weight: 600;
  text-decoration: none !important;
  transition: all 0.2s ease;
  font-family: 'Poppins', sans-serif;
}

.modal-btn-confirm:hover {
  background: #e63960;
  transform: translateY(-2px);
  box-shadow: 0 6px 15px rgba(255, 65, 108, 0.3);
}
</style>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const modal = document.getElementById('deleteModalOverlay');
    const cancelBtn = document.getElementById('cancelDeleteBtn');
    const confirmBtn = document.getElementById('confirmDeleteBtn');
    
    // 1. Find EVERY button in the project that has the class 'btn-delete'
    const deleteButtons = document.querySelectorAll('.btn-delete');
    
    deleteButtons.forEach(btn => {
        // 2. Remove the old ugly browser confirm popup from the HTML
        btn.removeAttribute('onclick');
        
        // 3. Attach our custom centered modal logic
        btn.addEventListener('click', function(e) {
            e.preventDefault(); // Stop the link from redirecting instantly
            
            // Steal the href link from the button they clicked, and give it to the Modal's confirm button
            const deleteUrl = this.getAttribute('href');
            confirmBtn.setAttribute('href', deleteUrl);
            
            // Show the modal
            modal.style.display = 'flex';
        });
    });

    // Close modal when user clicks Cancel
    cancelBtn.addEventListener('click', function() {
        modal.style.display = 'none';
    });
    
    // Close modal if user clicks the dark background outside the box
    window.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });
});
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<script>
  // Your existing legacy jQuery functions
  $(document).ready(function(){
    $(document).on("click", ".del_expense", function() {
      let result = confirm("Do you want to delete this expense?");
      if (result) {
        let del_id = $(this).attr("id");
        $.ajax({
          url: "delete_expense.php", 
          method: "POST",
          data: {del_id:del_id},
          success: function(response){
            alert("File deleted successfully");
            window.location.reload();
          }
        })
      }
    });

    $(document).on("click", ".del_user", function() {
      let result = confirm("Do you want to delete this user?");
      if (result) {
        let del_user_id = $(this).attr("id");
        $.ajax({
          url: "delete_user.php", 
          method: "POST",
          data: {del_user_id:del_user_id},
          success: function(response){
            alert("User deleted successfully");
            window.location.reload();
          }
        })
      }
    });
  });
</script>