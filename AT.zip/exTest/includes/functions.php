<?php

function my_alert($color , $msg)
{
  // Generate a random ID so this works even if there are multiple alerts
  $alert_id = 'alert_' . uniqid();
?>
<link rel="stylesheet" href="./css/alert.css">
  <input type="checkbox" id="<?php echo $alert_id; ?>" class="alert-toggle">
  
  <div class="alert alert-<?php echo $color ?>" role="alert">
    <?php echo $msg ?>
    
    <label for="<?php echo $alert_id; ?>" class="custom-close-btn">&times;</label>
  </div>
<?php
}


// check user
function check_user()
{
  if(!isset($_SESSION['is_login']) == true){
  echo "Logged in";
  }
}

//customize date
function customize_date($date){
  $formated_date = date("d-m-Y",strtotime($date));
  echo $formated_date ;
}

?>

