<?php
$pageTitle = "Profile Settings";
include("./includes/header.php");
include("./includes/functions.php");
include("./includes/db_conn.php");
include("./includes/gen_navbar.php");

check_user();
$current_user_id = $_SESSION['reg_id']; // Logged-in user ki ID
$alert_type = "";
$error_msg = "";

// 1. UPDATE LOGIC: Jab user "Save Changes" par click kare
if (isset($_POST['save_profile'])) {
    $first_name = $_POST['first_name'];
    $last_name  = $_POST['last_name'];
    $email      = $_POST['email'];
    $phone      = $_POST['phone'];
    $location   = $_POST['location'];

    // 'reg_users' table mein usi user ki details update karein
    $sql = "UPDATE reg_users SET 
            first_name = '$first_name', 
            last_name = '$last_name', 
            email = '$email', 
            phone = '$phone', 
            location = '$location' 
            WHERE reg_id = $current_user_id";

    if (mysqli_query($conn, $sql)) {
        $alert_type = "success";
    } else {
        $alert_type = "danger";
        $error_msg = mysqli_error($conn);
    }
}

// 2. FETCH LOGIC: Database se pehle se save details nikal kar form mein dikhana
$fetch_query = "SELECT * FROM reg_users WHERE reg_id = $current_user_id";
$run_fetch = mysqli_query($conn, $fetch_query);
$user_data = mysqli_fetch_assoc($run_fetch);

// Agar null hai toh blank string set kar do
$db_first_name = $user_data['first_name'] ?? "";
$db_last_name  = $user_data['last_name'] ?? "";
$db_email      = $user_data['email'] ?? "";
$db_phone      = $user_data['phone'] ?? "";
$db_location   = $user_data['location'] ?? "";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Profile Settings</title>
    <link rel="stylesheet" href="./css/style.css">
    <style>
        .success-alert {
            position: fixed; bottom: -100px; left: 50%; transform: translateX(-50%);
            background: #00b894; color: white; padding: 16px 32px; border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 184, 148, 0.3); z-index: 9999;
            animation: slideInOut 4s ease-in-out forwards;
        }
        @keyframes slideInOut {
            0% { bottom: -100px; }
            15% { bottom: 30px; }
            85% { bottom: 30px; }
            100% { bottom: -100px; }
        }
        .form-control {
            width: 100%; padding: 10px; border-radius: 8px; border: 1px solid #ccc;
        }
        .btn-save {
            background-color: #2E6F40; color: white; padding: 12px 25px; 
            border: none; border-radius: 10px; cursor: pointer; font-weight: bold; width: 100%;
        }
        .btn-save:hover { background-color: #1e4f2d; }
    </style>
</head>
<body style="background-color: #f8f9fa;">

<?php 
// Show the alert ONLY if the database query was successful
if ($alert_type == "success"): ?>
    <div class="success-alert">✓ Profile changes saved successfully!</div>
<?php elseif ($alert_type == "danger"): ?>
    <div class="success-alert" style="background: #ff7675;">Error: <?php echo $error_msg; ?></div>
<?php endif; ?>

<div class="profile-container" style="max-width: 500px; margin: 40px auto;">
    <div class="settings-card" style="background: #fff; padding: 40px; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.08);">
        
        <div class="header-flex" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
            <h2 style="margin: 0; color: #333;">Personal Info</h2>
            <span style="background: #e8f0fe; color: #4e73df; padding: 6px 15px; border-radius: 20px; font-size: 13px; font-weight: 600;">Active Account</span>
        </div>

        <form action="" method="POST" style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            
            <div class="field">
                <label style="display: block; font-size: 13px; font-weight: 600; margin-bottom: 8px;">First Name</label>
                <input type="text" name="first_name" class="form-control" value="<?php echo htmlspecialchars($db_first_name); ?>" required>
            </div>

            <div class="field">
                <label style="display: block; font-size: 13px; font-weight: 600; margin-bottom: 8px;">Last Name</label>
                <input type="text" name="last_name" class="form-control" value="<?php echo htmlspecialchars($db_last_name); ?>" required>
            </div>

            <div class="field" style="grid-column: span 2;">
                <label style="display: block; font-size: 13px; font-weight: 600; margin-bottom: 8px;">Email Address</label>
                <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($db_email); ?>" required>
            </div>

            <div class="field" style="grid-column: span 2;">
                <label style="display: block; font-size: 13px; font-weight: 600; margin-bottom: 8px;">Phone Number</label>
                <input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($db_phone); ?>">
            </div>

            <div class="field" style="grid-column: span 2;">
                <label style="display: block; font-size: 13px; font-weight: 600; margin-bottom: 8px;">Location</label>
                <input type="text" name="location" class="form-control" value="<?php echo htmlspecialchars($db_location); ?>">
            </div>
        
            <div class="buttons" style="grid-column: span 2; margin-top: 10px;">
                <button type="submit" name="save_profile" class="btn-save">Save Changes</button>
            </div>
        </form>

        <div style="text-align: center; margin-top: 25px;">
            <a href="./update_user_pass.php?update_pass_id=<?php echo $current_user_id; ?>" style="color: #e74c3c; text-decoration: none; font-weight: 600; font-size: 14px;">Update Password?</a>
        </div>
    </div>
</div>


</body>
</html>