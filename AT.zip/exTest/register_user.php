<?php
include("./includes/header.php");
include("./includes/functions.php");

if (isset($_REQUEST['register'])){
  include("./includes/db_conn.php");

  // getting input values from html form
  $user_name = $_REQUEST['user_name'];
  $user_password = $_REQUEST['user_password'];

  //encrypted password
  $enc_pass = password_hash($user_password,PASSWORD_BCRYPT);

  // Inserting data into database
  $sql = "INSERT INTO reg_users (user_name, user_password)
  VALUES ('$user_name', '$enc_pass')";

  if (mysqli_query($conn, $sql)) {
  my_alert("success", "Registered succesfully");
  } else {
  my_alert("danger", "Error ");
  }

  mysqli_close($conn);
  }
?>

<link rel="stylesheet" href="./css/style.css">
<nav class="custom-navbar">
  <div class="nav-brand">Expense Management System</div>
  <div class="nav-links">
    <a href="./login_user.php" class="btn-login">Login</a>
  </div>
</nav>

<div class="container">
 <div class="card my-card">
    <div class="card-header bg-primary text-white">
    Register User
    </div>
    <div class="card-body">
      <div class="row">
        <div class="col-12">
          <form method="POST">
            <div class="mb-3">
              <label for="" class="form-label">User Name</label>
              <input type="text" class="form-control" name="user_name" required>
            </div>
            <div class="mb-3">
              <label for="" class="form-label">Password</label>
              <input type="password" class="form-control" name="user_password" required>
            </div>
            <div class="mb-3">
              <button type="submit" name="register" class="btn btn-primary w-100">Register</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
