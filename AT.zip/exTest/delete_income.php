<?php
session_start();
include("./includes/db_conn.php");

// Security check: Make sure user is logged in
if(!isset($_SESSION['reg_id'])){
    header("Location: login.php");
    exit();
}

// Get the ID from URL (checking common variable names like 'id' or 'delete_id')
$del_id = isset($_GET['delete_id']) ? $_GET['delete_id'] : (isset($_GET['id']) ? $_GET['id'] : null);

if($del_id){
  $current_user_id = $_SESSION['reg_id'];

  // Secure Delete Query: Checks BOTH Income_ID and user_ID
  $del_query = "DELETE FROM income WHERE Income_ID = '$del_id' AND user_ID = '$current_user_id'";
  $run_del_query = mysqli_query($conn, $del_query);

  if($run_del_query){
    echo "<script>alert('Income Record Deleted Successfully'); window.location.href='display_income.php';</script>";
  } else {
    echo "<script>alert('Error: Could not delete record'); window.location.href='display_income.php';</script>";
  }
  
  mysqli_close($conn);
} else {
    header("Location: display_income.php");
}
?>