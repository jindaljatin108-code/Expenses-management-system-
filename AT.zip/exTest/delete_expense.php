<?php
include("./includes/header.php");
include("./includes/functions.php");
include("./includes/db_conn.php");

// if(isset($_REQUEST['del_expense_id'])){

//   $del_expense_id = $_REQUEST['del_expense_id'];

//   $del_query = "DELETE FROM expense_info WHERE item_id=$del_expense_id";
//   $run_del_query = mysqli_query($conn, $del_query);

//   if($run_del_query){
//     my_alert("success", "User Deleted Successfully");
//     header("Location: ./all_expenses.php");
//   }else {
//     my_alert("danger", "Something Went Wrong! While Deleting The User");
//   }

//   mysqli_close($conn);
// }

if(isset($_REQUEST['del_id'])){

  $del_expense_id = $_REQUEST['del_id'];
  $current_user_id = $_SESSION['reg_id']; // Logged-in user ki ID

  // Table ka exact naam aur columns (expense_id, user_id)
  $del_query = "DELETE FROM expense WHERE expense_id = $del_expense_id AND user_id = $current_user_id";
  $run_del_query = mysqli_query($conn, $del_query);

  if($run_del_query){
    echo 1;
  }else {
    echo 0;
  }

  mysqli_close($conn);
}

?>
