<?php

include("./includes/header.php");
include("./includes/functions.php");

if(isset($_SESSION['message']) && isset($_SESSION['color'])){
    echo my_alert($_SESSION['color'],$_SESSION['message']);
    unset($_SESSION['message'], $_SESSION['color']);
}

if (isset($_REQUEST['login'])){
  include("./includes/db_conn.php");

  // getting input values from html form
  $user_name = $_REQUEST['user_name'];
  $user_password = $_REQUEST['user_password'];

  $login_query = "SELECT * FROM reg_users WHERE user_name='$user_name'";
  $result_login_query = mysqli_query($conn,$login_query);

  if(mysqli_num_rows($result_login_query) == 1){
    $row = mysqli_fetch_assoc($result_login_query);
    $db_user_name = $row['user_name'];
    $db_user_pass = $row['user_password'];

    if(password_verify($user_password,$db_user_pass)){

      $_SESSION['name'] = $db_user_name;
      $_SESSION['reg_id'] = $row['reg_id'];
      $_SESSION['is_login'] = true;

      // to show notification of success
      $_SESSION['message'] = "Login Successful";
      $_SESSION['color'] = "success";
      header("Location: dashboard.php");
    }else{
      my_alert("danger","Incorrect Password");
    }
  }else{
    my_alert ("danger","User Doest not exist");
  }

  mysqli_close($conn);
  }

?>

<link rel="stylesheet" href="./css/style.css">
<nav class="custom-navbar">
  <div class="nav-brand">Expense Management System</div>
  <div class="nav-links">
    <a href="./register_user.php" class="btn-login">Register</a>
  </div>
</nav>

<div class="container">
 <div class="card my-card">
    <div class="card-header bg-primary text-white">
    Login
    </div>
    <div class="card-body">
      <div class="row">
        <div class="col-12">
          <form method="POST">
            <div class="mb-3">
              <label for="" class="form-label">User Name</label>
              <input type="text" class="form-control" name="user_name" required>
            </div>
            <div class="mb-3">
              <label for="" class="form-label">Password</label>
              <input type="password" class="form-control" name="user_password" required>
            </div>
            <div class="mb-3">
              <button type="submit" name="login" class="btn btn-primary w-100">Login</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>


