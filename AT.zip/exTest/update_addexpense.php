<?php
$pageTitle = "Update Expense";
include("./includes/header.php");
include("./includes/functions.php");
include("./includes/db_conn.php");
include("./includes/gen_navbar.php"); 

check_user();
$current_user_id = $_SESSION['reg_id']; 

// Initialize variables
$expense_id = "";
$expense_name = "";
$amount = "";
$payment_mode = "";
$date = "";
$description = "";

// 1. Fetch existing data to fill the form 
if(isset($_GET['edit_id'])){
    $expense_id = $_GET['edit_id'];
    $fetch_query = "SELECT * FROM expense WHERE expense_id = $expense_id AND user_id = $current_user_id";
    $run_fetch = mysqli_query($conn, $fetch_query);

    if($row = mysqli_fetch_assoc($run_fetch)){
        $expense_name = $row['expense_name']; 
        $amount       = $row['amount'];
        $payment_mode = $row['payment_mode'];
        $date         = $row['date'];
        $description  = $row['description']; 
    }
}

// 2. Update the data on Form Submission
if(isset($_POST['update_expense_btn'])){
    $expense_id       = $_POST['hidden_id'];
    $new_expense_name = $_POST['expense_name'];
    $new_amount       = $_POST['amount'];
    $new_mode         = $_POST['payment_mode'];
    $new_date         = $_POST['date'];
    $new_description  = $_POST['description']; 

    $update_query = "UPDATE expense SET 
                    expense_name = '$new_expense_name', 
                    amount = '$new_amount', 
                    payment_mode = '$new_mode', 
                    date = '$new_date',
                    description = '$new_description' 
                    WHERE expense_id = $expense_id AND user_id = $current_user_id";

    $run_update = mysqli_query($conn, $update_query);

    if($run_update){
        echo "<script>alert('Expense Updated Successfully'); window.location.href='manage_expense.php';</script>";
    } else {
        my_alert("danger", "Failed to update expense: " . mysqli_error($conn));
    }
}
?>

<style>
/* --- Google Fonts --- */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap');

/* --- Global Reset --- */
* {
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
}

body {
    margin: 0;
    padding: 0;
    background-color: #CFFFDC; /* Light Mint base */
    color: #253D2C; 
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

/* --- Form Container Card --- */
.container {
    max-width: 800px;
    margin: 60px auto 40px;
    padding: 50px;
    background-color: #ffffff;
    box-shadow: 0 10px 30px rgba(37, 61, 44, 0.08); 
    border-radius: 12px;
    flex: 1;
}

h2 {
    text-align: center;
    margin-bottom: 40px;
    color: #2E6F40; 
    font-weight: 700;
    letter-spacing: 1px;
}

/* --- Perfect 2-Column Grid --- */
form {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 25px;
}

/* Base styling for all inputs and dropdowns */
form input, form select {
    width: 100%;
    padding: 16px 18px;
    border: 1px solid #e0e5e2; 
    border-radius: 6px;
    font-size: 1rem;
    color: #333;
    background-color: #ffffff;
    transition: border-color 0.3s ease;
    outline: none;
}

form input::placeholder {
    color: #9fae9f; 
}

form input:focus, form select:focus {
    border-color: #68BA7F; 
}

/* Custom class to force elements to stretch across both columns */
.full-width {
    grid-column: span 2;
}

/* --- Submit Button --- */
form button {
    background-color: #68BA7F; 
    color: white;
    border: none;
    cursor: pointer;
    padding: 16px;
    font-size: 1.15rem;
    font-weight: 600;
    border-radius: 6px;
    transition: background-color 0.3s ease;
    margin-top: 10px;
}

form button:hover {
    background-color: #5aa771; 
}

/* --- Mobile Responsiveness --- */
@media (max-width: 768px) {
    .container {
        padding: 30px 20px;
        margin-top: 30px;
    }
    form {
        grid-template-columns: 1fr; 
    }
    .full-width {
        grid-column: 1; 
    }
}
</style>

<div class="container">
    <h2>UPDATE EXPENSE</h2>
    
    <form method="POST">
        <input type="hidden" name="hidden_id" value="<?php echo $expense_id; ?>">

        <input type="text" name="expense_name" placeholder="Expense Name" value="<?php echo htmlspecialchars($expense_name); ?>" required>
        <input type="number" step="0.01" name="amount" placeholder="Amount" value="<?php echo htmlspecialchars($amount); ?>" required>

        <input type="text" name="description" placeholder="Description" class="full-width" value="<?php echo htmlspecialchars($description); ?>" required>

        <input type="date" name="date" value="<?php echo $date; ?>" required>
        <select name="payment_mode" required>
            <option value="" disabled>Select Payment Mode</option>
            <option value="Cash" <?php if($payment_mode == 'Cash') echo 'selected'; ?>>Cash</option>
            <option value="UPI" <?php if($payment_mode == 'UPI') echo 'selected'; ?>>UPI</option>
            <option value="cards" <?php if($payment_mode == 'cards') echo 'selected'; ?>>Debit/Credit Card</option>
        </select>

        <button type="submit" name="update_expense_btn" class="full-width">Save Changes</button>
    </form>
</div>

