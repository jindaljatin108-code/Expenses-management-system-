<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About - Expense Manager</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <link rel="stylesheet" href="./css/about.css">
</head>

<body>

    <div class="navbar">
        <h2>Expense Manager</h2>
        <div class="nav-links">
            <a href="./index.php">Home</a>
        </div>
    </div>

    <div class="banner">
        <h1>About Expense Manager</h1>
        <p>Smart way to manage your daily finances</p>
    </div>

    <div class="about">
        <p>
            The Expense Management System is a web-based application developed to help users 
            manage their daily income and expenses efficiently. It allows users to record 
            transactions, track spending habits, and generate reports for better financial planning.
        </p>

        <div class="cards">
            <div class="card">
                <i class="fas fa-bullseye"></i>
                <h3>Objective</h3>
                <p>To provide an easy and efficient way to manage financial records.</p>
            </div>

            <div class="card">
                <i class="fas fa-code"></i>
                <h3>Technology</h3>
                <p>HTML, CSS, JavaScript, PHP, and MySQL are used.</p>
            </div>

            <div class="card">
                <i class="fas fa-chart-bar"></i>
                <h3>Features</h3>
                <p>Add expenses, track records, and generate reports easily.</p>
            </div>
        </div>
    </div> 
    <div>
      <footer class="footer">
        <div class="footer-content">
            <div class="footer-section">
                <h4>ExpenseTrack</h4>
                <p>Smart expense management for everyone.</p>
            </div>
            <div class="footer-section">
                
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About</a></li>
                </ul>
            </div>
           
            <div class="footer-section">
                <ul>
                    <li><a href="#">Privacy Policy</a></li>
                    <p>This system does not share user data with third parties. All data is stored securely.</p>
                    <li><a href="#">Terms & Conditions </a></li>
                    <p>This project is developed for educational purposes. Users must use it responsibly.</p>
                    
                </ul>
            </div>
            
            <div class="footer-section">
                <ul>
                    <li><a href="#contact">Contact</a></li>
                    <p> Email :support@expensetrack.com</p>
                    <p> Phone :+91 12345 67892</p>
                    
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 ExpenseTrack. All rights reserved.</p>
        </div>
      </footer>
    </div>