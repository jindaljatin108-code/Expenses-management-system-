<?php
$pageTitle = "Update Password";
include("./includes/header.php");
include("./includes/functions.php");
include("./includes/db_conn.php");
include("./includes/gen_navbar.php");

check_user();
$current_user_id = $_SESSION['reg_id']; // Logged-in user ID
$alert_type = "";
$alert_msg = "";

// Password Change Logic
if(isset($_POST['change_password'])){
    $current_pass = $_POST['current_pass'];
    $new_pass = $_POST['new_pass'];
    $confirm_pass = $_POST['confirm_pass'];

    // 1. Database se user ka current hashed password nikalna
    $fetch_query = "SELECT user_password FROM reg_users WHERE reg_id = $current_user_id";
    $run_fetch = mysqli_query($conn, $fetch_query);
    
    if($row = mysqli_fetch_assoc($run_fetch)){
        $db_password = $row['user_password'];

        // 2. Verify karna ki user ne purana password sahi dala hai ya nahi
        if(password_verify($current_pass, $db_password)){
            
            // 3. Check karna ki Naya aur Confirm password match hote hain
            if($new_pass === $confirm_pass){
                
                // 4. Naye password ko encrypt (hash) karna
                $new_hashed_pass = password_hash($new_pass, PASSWORD_BCRYPT);
                
                // 5. Database mein update karna
                $update_query = "UPDATE reg_users SET user_password = '$new_hashed_pass' WHERE reg_id = $current_user_id";
                $run_update = mysqli_query($conn, $update_query);

                if($run_update){
                    $alert_type = "success";
                    $alert_msg = "Password updated successfully!";
                } else {
                    $alert_type = "danger";
                    $alert_msg = "Database error: Failed to update password.";
                }
            } else {
                $alert_type = "danger";
                $alert_msg = "New Password and Confirm Password do not match!";
            }
        } else {
            $alert_type = "danger";
            $alert_msg = "Incorrect Current Password!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        .form-control {
            width: 100%; padding: 12px; border-radius: 8px; border: 1px solid #ccc; margin-bottom: 5px;
        }
        .btn-update {
            background-color: #2E6F40; color: white; padding: 12px 25px; 
            border: none; border-radius: 8px; cursor: pointer; font-weight: bold; width: 100%; transition: 0.3s;
        }
        .btn-update:hover { background-color: #1e4f2d; }
        .custom-alert {
            padding: 15px; margin-bottom: 20px; border-radius: 8px; text-align: center; font-weight: 600;
        }
        .alert-success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-danger { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
    </style>
</head>
<body style="background-color: #f4f7f6;">

<div class="container" style="max-width: 450px; margin: 60px auto;">
    
    <?php if($alert_type != ""): ?>
        <div class="custom-alert alert-<?php echo $alert_type; ?>">
            <?php echo $alert_msg; ?>
        </div>
    <?php endif; ?>

    <div class="card shadow" style="background: #fff; padding: 30px; border-radius: 15px; border: none;">
        <h3 style="text-align: center; color: #333; margin-bottom: 25px; font-weight: bold;">Change Password</h3>
        
        <form method="POST">
            <div style="margin-bottom: 20px;">
                <label style="font-weight: 600; font-size: 14px; color: #555;">Current Password</label>
                <input type="password" name="current_pass" class="form-control" placeholder="Enter current password" required>
            </div>

            <div style="margin-bottom: 20px;">
                <label style="font-weight: 600; font-size: 14px; color: #555;">New Password</label>
                <input type="password" name="new_pass" class="form-control" placeholder="Enter new password" required>
            </div>

            <div style="margin-bottom: 25px;">
                <label style="font-weight: 600; font-size: 14px; color: #555;">Confirm New Password</label>
                <input type="password" name="confirm_pass" class="form-control" placeholder="Re-enter new password" required>
            </div>

            <button type="submit" name="change_password" class="btn-update">Update Password</button>
        </form>

        <div style="text-align: center; margin-top: 20px;">
            <a href="./profile.php" style="color: #6c757d; text-decoration: none; font-size: 14px;">&larr; Back to Profile</a>
        </div>
    </div>
</div>

<?php include("./includes/footer.php"); ?>
</body>
</html>