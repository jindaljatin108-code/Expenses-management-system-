<?php 
include("./includes/header.php"); 
include("./includes/db_conn.php"); 
include("./includes/functions.php"); 
include("./includes/gen_navbar.php");

// if(isset($_SESSION['message']) && isset($_SESSION['color'])){
//     echo my_alert($_SESSION['color'],$_SESSION['message']);
//     unset($_SESSION['message'], $_SESSION['color']);
// }
check_user();
$current_user_id = $_SESSION['reg_id']; // Logged in user ki ID

// Fetch Recent Activity before HTML starts
$sql = "
    (SELECT source AS name, amount, date, 'income' AS type FROM income WHERE user_ID = '$current_user_id')
    UNION ALL
    (SELECT expense_name, amount, date, 'expense' AS type FROM expense WHERE User_ID = '$current_user_id')
    ORDER BY date DESC LIMIT 10";

$activities = $conn->query($sql);

?>
<style>
        /* Table Styling */
        .table-container { background: #fff; padding: 25px; border-radius: 12px; margin-top: 20px; color: #333; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
        .amt-income { color: #2ecc71; font-weight: bold; }
        .amt-expense { color: #e74c3c; font-weight: bold; }
    </style>
<title>Dashboard</title>


<link rel="stylesheet" href="css/dashboard.css">
<link rel="stylesheet" href="css/alert.css">
    <div class="dashboard-container">

        <?php
            // Catch and display the success alert beautifully
            if(isset($_SESSION['message']) && isset($_SESSION['color'])){
                my_alert($_SESSION['color'], $_SESSION['message']);
                unset($_SESSION['message'], $_SESSION['color']);
            }
        ?>



        <div class="stats-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px;">
            <div class="stat-card">
                <div class="stat-icon"><i class="fa fa-users"></i></div>
                <div class="stat-info">
                    <h3>Total Users</h3>
                    <p class="stat-value">
                        <?php 
                        $user_query = "SELECT user_name from reg_users";
                        $run_user_query = mysqli_query($conn, $user_query);
                        echo mysqli_num_rows($run_user_query);
                        ?>
                    </p>
                </div>
            </div>

           <div class="stat-card income">
                <div class="stat-icon"><i class="fa fa-arrow-up"></i></div>
                <div class="stat-info">
                    <h3>Total Income</h3>
                    <p class="stat-value">₹ 
                        <?php 
                        $res_inc = mysqli_query($conn, "SELECT SUM(Amount) as total FROM income WHERE user_ID = '$current_user_id'");
                        $inc_row = mysqli_fetch_assoc($res_inc);
                        $total_income = $inc_row['total'] ?? 0;
                        echo number_format($total_income, 2);
                        ?>
                    </p>
                </div>
            </div>

            <div class="stat-card expense">
                <div class="stat-icon"><i class="fa fa-arrow-down"></i></div>
                <div class="stat-info">
                    <h3>Total Expense</h3>
                    <p class="stat-value">₹ 
                        <?php 
                        $res_exp = mysqli_query($conn, "SELECT SUM(Amount) as total FROM expense WHERE User_ID = '$current_user_id'");
                        $exp_row = mysqli_fetch_assoc($res_exp);
                        $total_expense = $exp_row['total'] ?? 0;
                        echo number_format($total_expense, 2);
                        ?>
                    </p>
                </div>
            </div>

            <div class="stat-card balance">
                <div class="stat-icon"><i class="fa fa-balance-scale"></i></div>
                <div class="stat-info">
                    <h3>Net Balance</h3>
                    <p class="stat-value">₹ <?php echo number_format($total_income - $total_expense, 2); ?></p>
                </div>
            </div>

            <div class="stat-card transactions">
                <div class="stat-icon"><i class="fa fa-list"></i></div>
                    <div class="stat-info">
                        <h3>Transactions</h3>
                        <p class="stat-value">
                            <?php 
                            $count_inc = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM income WHERE user_ID = '$current_user_id'"))['count'];
                            $count_exp = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM expense WHERE User_ID = '$current_user_id'"))['count'];
                            echo ($count_inc + $count_exp);
                            ?>
                        </p>
                    </div>
                </div>
            </div>

         <!-- Quick Actions -->
        <div class="quick-actions">
            <h2><i class="fa fa-bolt"></i> Quick Actions</h2>
            <div class="action-buttons">
                <a href="addexpense.php" class="action-btn expense-btn">
                    <i class="fa fa-minus-circle"></i>
                    <span>Add Expense</span>
                </a>
                <a href="income.php" class="action-btn income-btn">
                    <i class="fa fa-plus-circle"></i>
                    <span>Add Income</span>
                </a>
                <a href="report.php " class="action-btn report-btn">
                    <i class="fa fa-chart-bar"></i>
                    <span>View Reports</span>
                </a>
            </div>
        </div>

        <div class="table-container">
            <h3>Recent Activity</h3>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Expense/Source</th>
                        <th>Type</th>
                        <th>Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($activities && $activities->num_rows > 0): ?>
                        <?php while($row = $activities->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo date("d M, Y", strtotime($row['date'])); ?></td>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><?php echo ucfirst($row['type']); ?></td>
                            <td class="<?php echo ($row['type'] == 'income') ? 'amt-income' : 'amt-expense'; ?>">
                                <?php echo ($row['type'] == 'income') ? '+ ' : '- '; ?>
                                ₹<?php echo number_format($row['amount'], 2); ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="4">No recent transactions found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>
<?php include("./includes/footer.php"); ?>