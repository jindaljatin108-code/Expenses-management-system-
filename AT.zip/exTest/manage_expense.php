<?php
$title = "Manage Expenses";
include("./includes/header.php");
include("./includes/functions.php");
include("./includes/db_conn.php");
include("./includes/gen_navbar.php");
?>

<style>
/* --- Google Fonts --- */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap');

* {
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
}

body {
    margin: 0;
    padding: 0;
    background-color: #CFFFDC; /* Light Mint base */
    color: #253D2C;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

/* --- Main Container --- */
.container {
    max-width: 95%; /* Stretches beautifully across the screen */
    width: 100%;
    margin: 40px auto;
    padding: 40px;
    background-color: #ffffff;
    box-shadow: 0 10px 30px rgba(37, 61, 44, 0.08);
    border-radius: 15px;
    flex: 1; 
}

/* --- Header Section --- */
.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
    padding-bottom: 20px;
    border-bottom: 2px solid #eef5f0;
}

.page-header h1 {
    color: #2E6F40; 
    font-weight: 700;
    letter-spacing: 1px;
    text-transform: uppercase;
    font-size: 1.8rem;
    margin: 0;
}

a.btn-add {
    background-color: #68BA7F; 
    color: #ffffff !important;
    text-decoration: none !important;
    padding: 12px 25px;
    font-weight: 600;
    border-radius: 8px;
    box-shadow: 0 4px 15px rgba(104, 186, 127, 0.3);
    transition: all 0.3s ease;
}

a.btn-add:hover {
    background-color: #2E6F40;
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(46, 111, 64, 0.35);
}

/* --- Data Table --- */
.table-wrapper {
    overflow-x: auto; 
    width: 100%;
}

.data-table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    border: 1px solid #eef5f0;
    border-radius: 10px;
    overflow: hidden;
}

.data-table th {
    background-color: #2E6F40;
    color: white;
    padding: 18px 15px;
    font-weight: 600;
    text-transform: uppercase;
    font-size: 0.95rem;
    letter-spacing: 0.5px;
    text-align: left;
}

.data-table td {
    padding: 16px 15px;
    border-bottom: 1px solid #eef5f0;
    color: #4a5d50;
    font-size: 0.95rem;
    vertical-align: middle;
}

.data-table tbody tr:hover td {
    background-color: #fcfdfc;
}

.data-table tbody tr:last-child td {
    border-bottom: none;
}

.amount-cell {
    color: #ff416c; /* Made expenses red to contrast with green income! */
    font-size: 1.05rem;
    font-weight: 600;
}

/* --- Action Buttons --- */
.action-cells {
    display: flex;
    gap: 10px;
}

a.btn-edit, a.btn-delete {
    text-decoration: none !important;
    padding: 6px 15px;
    font-weight: 600;
    border-radius: 6px;
    transition: all 0.3s ease;
    font-size: 0.85rem;
}

a.btn-edit {
    color: #17a2b8 !important;
    border: 2px solid #17a2b8;
}

a.btn-edit:hover {
    background-color: #17a2b8;
    color: white !important;
}

a.btn-delete {
    color: #ff416c !important;
    border: 2px solid #ff416c;
}

a.btn-delete:hover {
    background-color: #ff416c;
    color: white !important;
}

.empty-state {
    text-align: center;
    color: #ff416c;
    font-weight: 600;
    padding: 40px !important;
    font-size: 1.1rem;
}

/* --- Mobile Breakpoints --- */
@media (max-width: 600px) {
    .page-header {
        flex-direction: column;
        gap: 15px;
        text-align: center;
    }
}
</style>

<div class="container">
    
    <div class="page-header">
        <h1>Manage Expenses</h1>
        <a href="./add_expense.php" class="btn-add">Add Expense</a>
    </div>

    <div class="table-wrapper">
        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Amount</th>
                    <th>Payment Mode</th>
                    <th>Date</th>
                    <th>Description</th>
                    <th>Operations</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    // Logged-in user ki id nikal li
                    $current_user_id = $_SESSION['reg_id']; 

                    // Query mein user_id ka filter laga diya
                    $fetch_data = "SELECT * FROM expense WHERE user_id = '$current_user_id' ORDER BY date DESC";
                    $run_fetch_data = mysqli_query($conn, $fetch_data);
                    $counter = 1;

                    if (mysqli_num_rows($run_fetch_data) > 0) {
                        while ($row = mysqli_fetch_assoc($run_fetch_data)) {
                ?>
                        <tr>
                            <td><strong><?php echo $counter; ?></strong></td>
                            <td><?php echo htmlspecialchars($row['expense_name']); ?></td>
                            
                            <td class="amount-cell">- ₹<?php echo number_format($row['amount'], 2); ?></td>
                            
                            <td><?php echo htmlspecialchars($row['payment_mode']); ?></td>
                            <td><?php echo date("d M, Y", strtotime($row['date'])); ?></td>
                            <td><?php echo htmlspecialchars($row['description']); ?></td>
                            
                            <td class="action-cells">
                                <a class="btn-edit" href="./edit_expense.php?edit_expense_id=<?php echo $row['expense_id']; ?>">Edit</a>
                                <a class="btn-delete" href="./delete_expense.php?del_id=<?php echo $row['expense_id']; ?>" onclick="return confirm('Are you sure you want to delete this expense?')">Delete</a>
                            </td>
                        </tr>
                    <?php
                        $counter++;
                    }
                } else {
                    ?>
                    <tr>
                        <td colspan="7" class="empty-state">
                            No Expenses Found
                        </td>
                    </tr>
                <?php
                }
                mysqli_close($conn);
                ?>
            </tbody>
        </table>
    </div>
</div>
<?php
include("./includes/footer.php");
?>

