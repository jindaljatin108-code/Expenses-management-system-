<?php
$title = "Six Month Report";
include("./includes/header.php");
include("./includes/functions.php");
include("./includes/db_conn.php");
include("./includes/gen_navbar.php");

// Added check_user() for security
if(function_exists('check_user')) { check_user(); }

// 1. Define the 6-Month Range
$today = date("Y-m-d");
$start_date = date("Y-m-d", strtotime("-6 months")); 
$current_user_id = $_SESSION['reg_id']; 

// 2. Get Expenses for the range 
$get_exp = mysqli_query($conn, "SELECT date, payment_mode, amount FROM expense WHERE date BETWEEN '$start_date' AND '$today' AND User_ID = '$current_user_id' ORDER BY date DESC");

// 3. Get Income for the range 
$get_inc = mysqli_query($conn, "SELECT Date, source, Amount FROM income WHERE Date BETWEEN '$start_date' AND '$today' AND user_ID = '$current_user_id' ORDER BY Date DESC");

$total_balance = 0;
?>

<style>
/* --- Google Fonts --- */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap');

* {
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
}

body {
    margin: 0;
    padding: 0;
    background-color: #CFFFDC; /* Light Mint base */
    color: #253D2C;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

/* --- Main Container --- */
.container {
    max-width: 95%; 
    width: 100%;
    margin: 40px auto;
    padding: 40px;
    background-color: #ffffff;
    box-shadow: 0 10px 30px rgba(37, 61, 44, 0.08);
    border-radius: 15px;
    flex: 1; 
}

/* --- Header Section --- */
.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
    padding-bottom: 20px;
    border-bottom: 2px solid #eef5f0;
}

.page-header h1 {
    color: #2E6F40; 
    font-weight: 700;
    letter-spacing: 1px;
    text-transform: uppercase;
    font-size: 1.8rem;
    margin: 0 0 5px 0;
}

.date-subtitle {
    color: #68BA7F;
    font-weight: 600;
    font-size: 1rem;
    margin: 0;
}

/* --- Top Action Buttons --- */
.header-buttons {
    display: flex;
    gap: 15px;
}

a.btn-dashboard {
    background-color: #2E6F40; /* Dark Green for primary navigation */
    color: #ffffff !important;
    text-decoration: none !important;
    padding: 12px 25px;
    font-weight: 600;
    border-radius: 8px;
    box-shadow: 0 4px 15px rgba(46, 111, 64, 0.3);
    transition: all 0.3s ease;
}

a.btn-dashboard:hover {
    background-color: #1a4225;
    transform: translateY(-2px);
}

button.btn-print {
    background-color: transparent; 
    color: #2E6F40;
    border: 2px solid #2E6F40;
    padding: 12px 25px;
    font-weight: 600;
    border-radius: 8px;
    cursor: pointer;
    font-family: 'Poppins', sans-serif;
    font-size: 1rem;
    transition: all 0.3s ease;
}

button.btn-print:hover {
    background-color: #2E6F40;
    color: #ffffff;
    box-shadow: 0 4px 15px rgba(46, 111, 64, 0.2);
    transform: translateY(-2px);
}

/* --- Data Table --- */
.table-wrapper {
    overflow-x: auto; 
    width: 100%; 
}

.data-table {
    width: 100%; 
    border-collapse: separate;
    border-spacing: 0;
    border: 1px solid #eef5f0;
    border-radius: 10px;
    overflow: hidden;
}

.data-table th {
    background-color: #2E6F40;
    color: white;
    padding: 18px 15px;
    font-weight: 600;
    text-transform: uppercase;
    font-size: 0.95rem;
    letter-spacing: 0.5px;
    text-align: left;
}

.data-table td {
    padding: 16px 15px;
    border-bottom: 1px solid #eef5f0;
    color: #4a5d50;
    font-size: 0.95rem;
    vertical-align: middle;
}

.data-table tbody tr:hover td {
    background-color: #fcfdfc;
}

/* --- Colored Text & Badges --- */
.amount-income {
    color: #68BA7F;
    font-size: 1.05rem;
    font-weight: 600;
}

.amount-expense {
    color: #ff416c;
    font-size: 1.05rem;
    font-weight: 600;
}

.badge-income {
    background-color: #e8f5e9;
    color: #2E6F40;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: 600;
}

.badge-expense {
    background-color: #ffebee;
    color: #ff416c;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: 600;
}

/* --- Closing Balance Row --- */
.balance-row td {
    background-color: #f4faf6;
    font-size: 1.2rem;
    font-weight: 700;
    border-top: 2px solid #e0e5e2;
    text-align: right;
    color: #253D2C;
}

.balance-amount-positive { color: #68BA7F !important; }
.balance-amount-negative { color: #ff416c !important; }

/* Empty State */
.empty-state {
    text-align: center;
    color: #8fa896;
    font-weight: 500;
    padding: 40px !important;
    font-size: 1.1rem;
}

/* --- Print Styles (Hides buttons and navigation when printing) --- */
@media print {
    body { background-color: white !important; }
    .container { box-shadow: none !important; margin: 0 !important; padding: 0 !important; max-width: 100% !important; }
    .header-buttons, .dashboard-header, footer { display: none !important; }
    .data-table th { color: black !important; background-color: #f4f4f4 !important; border: 1px solid #ddd !important; }
    .data-table td { border: 1px solid #ddd !important; }
}

/* --- Mobile Breakpoints --- */
@media (max-width: 600px) {
    .page-header {
        flex-direction: column;
        gap: 15px;
        text-align: center;
    }
    .header-buttons {
        width: 100%;
        justify-content: center;
        flex-direction: column;
    }
}
</style>

<div class="container">
    
    <div class="page-header">
        <div>
            <h1>Six Month Summary</h1>
            <p class="date-subtitle">
                <?php echo date("M Y", strtotime($start_date)); ?> — <?php echo date("M Y", strtotime($today)); ?>
            </p>
        </div>
        <div class="header-buttons">
            <button onclick="window.print()" class="btn-print"><i class="fas fa-print"></i> Print Report</button>
            <a href="dashboard.php" class="btn-dashboard">Back to Dashboard</a>
        </div>
    </div>

    <div class="table-wrapper">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Type</th>
                    <th>Source / Mode</th>
                    <th>Amount</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $data_exists = false;

                // Display Expenses
                while($row = mysqli_fetch_assoc($get_exp)): 
                    $data_exists = true;
                    $total_balance -= $row['amount']; 
                ?>
                    <tr>
                        <td><?php echo customize_date($row['date']); ?></td>
                        <td><span class="badge-expense">Expense</span></td>
                        <td><?php echo htmlspecialchars($row['payment_mode']); ?></td>
                        <td class="amount-expense">- ₹<?php echo number_format($row['amount'], 2); ?></td>
                    </tr>
                <?php endwhile; ?>

                <!-- // Display Income -->
                <?php while($row = mysqli_fetch_assoc($get_inc)): 
                    $data_exists = true;
                    $total_balance += $row['Amount']; 
                ?>
                    <tr>
                        <td><?php echo customize_date($row['Date']); ?></td>
                        <td><span class="badge-income">Income</span></td>
                        <td><?php echo htmlspecialchars($row['source']); ?></td>
                        <td class="amount-income">+ ₹<?php echo number_format($row['Amount'], 2); ?></td>
                    </tr>
                <?php endwhile; ?>

                <!-- // Empty State -->
                <?php if(!$data_exists): ?>
                    <tr>
                        <td colspan="4" class="empty-state">No transactions found for the last six months.</td>
                    </tr>
                <?php endif; ?>

                <!-- // Closing Balance Footer -->
                <?php if($data_exists): ?>
                <tr class="balance-row">
                    <td colspan="3">Total Period Balance:</td>
                    <td class="<?php echo ($total_balance >= 0) ? 'balance-amount-positive' : 'balance-amount-negative'; ?>">
                        ₹ <?php echo number_format($total_balance, 2); ?>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

