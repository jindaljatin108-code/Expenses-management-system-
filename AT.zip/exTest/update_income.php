<?php
$pageTitle = "Update Income";
include("./includes/header.php");
include("./includes/functions.php");
include("./includes/db_conn.php");
include("./includes/gen_navbar.php"); 

check_user();
$current_user_id = $_SESSION['reg_id']; // Secure session ID

$income_id = "";
$source = "";
$amount = "";
$date = "";
$show_success_modal = false; // Our magic switch for the new modal!

// 1. FETCH DATA
if (isset($_GET['id'])) {
    $income_id = $_GET['id'];
    
    $fetch_query = "SELECT * FROM income WHERE Income_ID = '$income_id' AND user_ID = '$current_user_id'";
    $run_fetch = mysqli_query($conn, $fetch_query);

    if ($row = mysqli_fetch_assoc($run_fetch)) {
        $source = $row['source'];
        $amount = $row['Amount'];
        $date   = $row['Date'];
    }
}

// 2. UPDATE DATA
if (isset($_POST['update_income_btn'])) {
    $id_to_update = $_POST['hidden_id'];
    $new_source   = $_POST['source'];
    $new_amount   = $_POST['amount'];
    $new_date     = $_POST['date'];

    $update_query = "UPDATE income SET 
                    source = '$new_source', 
                    Amount = '$new_amount', 
                    Date = '$new_date' 
                    WHERE Income_ID = '$id_to_update' AND user_ID = '$current_user_id'";

    if (mysqli_query($conn, $update_query)) {
        // FLIP THE SWITCH TO TRUE INSTEAD OF USING THE UGLY BROWSER ALERT
        $show_success_modal = true;
        
        // Update the variables so the form underneath shows the new data
        $source = $new_source;
        $amount = $new_amount;
        $date   = $new_date;
    } else {
        my_alert("danger", "Failed to update income: " . mysqli_error($conn));
    }
}
?>

<style>
/* --- Google Fonts & Resets --- */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap');

* { box-sizing: border-box; font-family: 'Poppins', sans-serif; }

body {
    margin: 0; padding: 0;
    background-color: #CFFFDC; 
    color: #253D2C; 
    min-height: 100vh;
    display: flex; flex-direction: column;
}

/* --- Form Container Card --- */
.container {
    max-width: 800px;
    margin: 60px auto 40px;
    padding: 50px;
    background-color: #ffffff;
    box-shadow: 0 10px 30px rgba(37, 61, 44, 0.08); 
    border-radius: 12px;
    flex: 1;
}

h2 {
    text-align: center; margin-bottom: 40px;
    color: #2E6F40; font-weight: 700;
    letter-spacing: 1px; text-transform: uppercase;
}

/* --- 2-Column Grid --- */
form { display: grid; grid-template-columns: 1fr 1fr; gap: 25px; }

form input {
    width: 100%; padding: 16px 18px;
    border: 1px solid #e0e5e2; border-radius: 6px;
    font-size: 1rem; color: #333;
    background-color: #ffffff;
    transition: border-color 0.3s ease; outline: none;
}

form input::placeholder { color: #9fae9f; }
form input:focus { border-color: #68BA7F; }
.full-width { grid-column: span 2; }

form button {
    background-color: #68BA7F; color: white;
    border: none; cursor: pointer;
    padding: 16px; font-size: 1.15rem;
    font-weight: 600; border-radius: 6px;
    transition: background-color 0.3s ease; margin-top: 10px;
}
form button:hover { background-color: #5aa771; }

@media (max-width: 768px) {
    .container { padding: 30px 20px; margin-top: 30px; }
    form { grid-template-columns: 1fr; }
    .full-width { grid-column: 1; }
}

/* ==========================================
   CUSTOM SUCCESS MODAL STYLES
   ========================================== */
.success-modal-overlay {
    display: flex; /* Uses Flexbox to perfectly center the box */
    position: fixed;
    top: 0; left: 0; width: 100%; height: 100%;
    background: rgba(37, 61, 44, 0.7); 
    z-index: 9999;
    align-items: center; justify-content: center;
    backdrop-filter: blur(4px); 
}

.success-modal-box {
    background: #ffffff;
    padding: 40px;
    border-radius: 15px;
    text-align: center;
    max-width: 400px; width: 90%;
    box-shadow: 0 15px 40px rgba(0,0,0,0.25);
    animation: popIn 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275); 
}

@keyframes popIn {
    0% { transform: scale(0.8); opacity: 0; }
    100% { transform: scale(1); opacity: 1; }
}

.success-icon { font-size: 55px; margin-bottom: 10px; }

.success-modal-box h3 {
    color: #2E6F40; margin: 0 0 10px;
    font-weight: 700; letter-spacing: 0.5px;
}

.success-modal-box p {
    color: #4a5d50; margin-bottom: 25px; font-size: 0.95rem;
}

.modal-btn-return {
    display: inline-block;
    background: #68BA7F; color: white !important;
    text-decoration: none !important;
    padding: 12px 24px; border-radius: 8px;
    font-weight: 600; transition: all 0.2s ease;
}

.modal-btn-return:hover {
    background: #2E6F40; transform: translateY(-2px);
    box-shadow: 0 6px 15px rgba(104, 186, 127, 0.3);
}
</style>

<?php if ($show_success_modal): ?>
<div class="success-modal-overlay">
    <div class="success-modal-box">
        <div class="success-icon">✅</div>
        <h3>Success!</h3>
        <p>Income details have been updated successfully.</p>
        <a href="display_income.php" class="modal-btn-return">Return to Records</a>
    </div>
</div>
<?php endif; ?>

<div class="container">
    <h2>UPDATE INCOME</h2>
    
    <form method="POST">
        <input type="hidden" name="hidden_id" value="<?php echo htmlspecialchars($income_id); ?>">

        <input type="text" name="source" placeholder="Income Source" value="<?php echo htmlspecialchars($source); ?>" required>
        <input type="number" step="0.01" name="amount" placeholder="Amount (₹)" value="<?php echo htmlspecialchars($amount); ?>" required>

        <input type="date" name="date" class="full-width" value="<?php echo htmlspecialchars($date); ?>" required>

        <button type="submit" name="update_income_btn" class="full-width">Save Changes</button>
    </form>
</div>






