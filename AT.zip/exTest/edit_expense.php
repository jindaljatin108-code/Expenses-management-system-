<?php
include("./includes/header.php");
include("./includes/functions.php");
include("./includes/db_conn.php");
include("./includes/gen_navbar.php");

check_user();
$current_user_id = $_SESSION['reg_id']; 

$edit_expense_id = null;
$db_item_name = null;
$db_item_price = null;
$db_item_date = null;
$db_item_details = null;

// Fetching data from database 
if(isset($_REQUEST['edit_expense_id'])){
  $edit_expense_id = $_REQUEST['edit_expense_id'];
  $fetch_query = "SELECT * FROM expense WHERE expense_id = $edit_expense_id AND user_id = $current_user_id";
  $run_fetch_query = mysqli_query($conn, $fetch_query);

  if($row = mysqli_fetch_assoc($run_fetch_query)){
      $db_item_name = $row['expense_name'];
      $db_item_price = $row['amount'];
      $db_item_date = $row['date'];
      $db_item_details = $row['description']; 
  }
}

// Updating expense info in database
if(isset($_REQUEST['update_item'])){
  $update_item_name = $_REQUEST['update_item_name'];
  $update_item_price = $_REQUEST['update_item_price'];
  $update_item_date = $_REQUEST['update_item_date'];
  $update_item_details = $_REQUEST['update_item_details'];

  $update_query = "UPDATE expense SET expense_name='$update_item_name', amount='$update_item_price', date='$update_item_date', description='$update_item_details' WHERE expense_id = $edit_expense_id AND user_id = $current_user_id";
  
  $run_update_query = mysqli_query($conn, $update_query);

  if($run_update_query){
    my_alert("success", "Expense Updated Successfully");
    // Optional: Refresh the data so the inputs show the new values immediately
    $db_item_name = $update_item_name;
    $db_item_price = $update_item_price;
    $db_item_date = $update_item_date;
    $db_item_details = $update_item_details;
  }else{
    my_alert("danger", "Error While Updating the Expense: " . mysqli_error($conn));
  }
}

mysqli_close($conn);
?>

<style>
/* --- Google Fonts --- */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap');

* {
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
}

body {
    margin: 0;
    padding: 0;
    background-color: #CFFFDC; /* Light Mint base */
    color: #253D2C; 
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

/* --- Form Container Card --- */
.container {
    max-width: 800px;
    margin: 60px auto 40px;
    padding: 50px;
    background-color: #ffffff;
    box-shadow: 0 10px 30px rgba(37, 61, 44, 0.08); 
    border-radius: 12px;
    flex: 1;
}

h2 {
    text-align: center;
    margin-bottom: 40px;
    color: #2E6F40; 
    font-weight: 700;
    letter-spacing: 1px;
    text-transform: uppercase;
}

/* --- Perfect 2-Column Grid --- */
form {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 25px;
}

/* Base styling for all inputs */
form input {
    width: 100%;
    padding: 16px 18px;
    border: 1px solid #e0e5e2; 
    border-radius: 6px;
    font-size: 1rem;
    color: #333;
    background-color: #ffffff;
    transition: border-color 0.3s ease;
    outline: none;
}

form input::placeholder {
    color: #9fae9f; 
}

form input:focus {
    border-color: #68BA7F; 
}

/* Custom class to force elements to stretch across both columns */
.full-width {
    grid-column: span 2;
}

/* --- Submit Button --- */
form button {
    background-color: #68BA7F; 
    color: white;
    border: none;
    cursor: pointer;
    padding: 16px;
    font-size: 1.15rem;
    font-weight: 600;
    border-radius: 6px;
    transition: background-color 0.3s ease;
    margin-top: 10px;
}

form button:hover {
    background-color: #5aa771; 
}

/* --- Mobile Responsiveness --- */
@media (max-width: 768px) {
    .container {
        padding: 30px 20px;
        margin-top: 30px;
    }
    form {
        grid-template-columns: 1fr; 
    }
    .full-width {
        grid-column: 1; 
    }
}
</style>

<div class="container">
  <h2>UPDATE EXPENSE</h2>
  
  <form method="POST">
      <input type="text" name="update_item_name" placeholder="Expense Name" value="<?php echo htmlspecialchars($db_item_name); ?>" required>
      <input type="number" step="0.01" name="update_item_price" placeholder="Amount (₹)" value="<?php echo htmlspecialchars($db_item_price); ?>" required>

      <input type="text" name="update_item_details" placeholder="Expense Details / Description" class="full-width" value="<?php echo htmlspecialchars($db_item_details); ?>" required>
      
      <input type="date" name="update_item_date" class="full-width" value="<?php echo $db_item_date; ?>" required>
      
      <button type="submit" name="update_item" class="full-width">Update Expense</button>
  </form>
</div>
