<?php
include("./includes/header.php");
include("./includes/functions.php");
include("./includes/gen_navbar.php");
include("./includes/db_conn.php");

// Helper function to get expense totals efficiently
// Helper function to get expense totals efficiently (Updated for specific user)
function get_sum($conn, $start_date, $end_date = null) {
    $user_id = $_SESSION['reg_id']; // Logged-in user ki id yahan nikal li
    
    if ($end_date == null) {
        $sql = "SELECT SUM(amount) as total FROM expense WHERE date = '$start_date' AND User_ID = '$user_id'";
    } else {
        $sql = "SELECT SUM(amount) as total FROM expense WHERE date BETWEEN '$start_date' AND '$end_date' AND User_ID = '$user_id'";
    }
    $run = mysqli_query($conn, $sql);
    $data = mysqli_fetch_assoc($run);
    return $data['total'] ?? 0;
}

$today = date("Y-m-d");
?>

<link rel="stylesheet" href="./css/report.css">


<div class="container py-5">
    <div class="row px-3">
        

        <div class="col-xl-4 col-lg-6">
            <a href="./daily.php" class="text-decoration-none">
                <div class="card l-bg-cherry">
                    <div class="card-statistic-3 p-4">
                        <div class="card-icon card-icon-large"><i class="fas fa-shopping-cart"></i></div>
                        <div class="mb-4">
                            <h5 class="card-title mb-0">Daily Report</h5>
                        </div>
                        <h2 class="mb-0">₹<?php echo number_format(get_sum($conn, $today), 2); ?></h2>
                      
                    </div>
                </div>   
            </a>
        </div>

        <div class="col-xl-4 col-lg-6">
            <a href="./weekend.php" class="text-decoration-none">
                <div class="card l-bg-green">
                    <div class="card-statistic-3 p-4">
                        <div class="card-icon card-icon-large"><i class="fas fa-calendar-week"></i></div>
                        <div class="mb-4">
                            <h5 class="card-title mb-0">Weekly Report</h5>
                        </div>
                        <h2 class="mb-0">₹<?php echo number_format(get_sum($conn, date("Y-m-d", strtotime("-7 days")), $today), 2); ?></h2>
                    
               
                    </div>
                </div>
            </a>
        </div>

        <div class="col-xl-6 col-lg-6">
            <a href="./monthly.php" class="text-decoration-none">
                <div class="card l-bg-orange-dark">
                    <div class="card-statistic-3 p-4">
                        <div class="card-icon card-icon-large"><i class="fas fa-calendar-alt"></i></div>
                        <div class="mb-4">
                            <h5 class="card-title mb-0">Monthly Report</h5>
                        </div>
                        <h2 class="mb-0">₹<?php echo number_format(get_sum($conn, date("Y-m-d", strtotime("-1 month")), $today), 2); ?></h2>
                    
                    </div>
                </div>
            </a>
        </div>

        <div class="col-xl-6 col-lg-6">
            <a href="./six_month.php" class="text-decoration-none">
                <div class="card l-bg-cyan">
                    <div class="card-statistic-3 p-4">
                        <div class="card-icon card-icon-large"><i class="fas fa-chart-line"></i></div>
                        <div class="mb-4">
                            <h5 class="card-title mb-0">Six Month Report</h5>
                        </div>
                        <h2 class="mb-0">₹<?php echo number_format(get_sum($conn, date("Y-m-d", strtotime("-1 year")), $today), 2); ?></h2>
                    
                    </div>
                </div>
            </a>
        </div>

    </div>
</div>

