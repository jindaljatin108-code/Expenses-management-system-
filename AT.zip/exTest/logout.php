<?php
session_start();

// session_unset();
// session_destroy();

if(isset($_SESSION['is_login'])){

  unset($_SESSION['is_login']);

   // to show notification of success
  $_SESSION['message'] = "Logout Successfully";
  $_SESSION['color'] = "success";
}
header("Location: login_user.php");

?>